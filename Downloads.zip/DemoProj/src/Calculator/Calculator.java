package Calculator;

public interface Calculator {
	int add();
	int substract();
	int multiply();
	int division();
}
