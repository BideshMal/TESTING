package TrainingData;

public interface Training {
	public static final long id = 1195;
	String getTrainigVendorName();
	String getTrainerName();
	int getTotalDurtionInHrs();
	int getTotalNumberOfTrainees();
	
	
}
