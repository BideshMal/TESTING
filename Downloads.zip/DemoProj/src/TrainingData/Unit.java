package TrainingData;

public class Unit extends Module{
	protected String Uname;

    public Unit(String courseName, String moduleName, String unitName) {
        super(courseName, moduleName);
        this.Uname = unitName;
    }
	

}
