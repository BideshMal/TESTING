package TrainingData;

public class Topic extends Unit {
    protected String topicName;

    public Topic(String courseName, String moduleName, String unitName, String topicName) {
        super(courseName, moduleName, unitName);
        this.topicName = topicName;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }
}