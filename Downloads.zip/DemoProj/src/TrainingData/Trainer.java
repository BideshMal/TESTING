package TrainingData;

public class Trainer implements Training {
	private String trainingVendorName;
    private String trainerName;
    private int totalDurationInHrs;
    private int totalNumberOfTrainees;

    
    public Trainer(String trainingVendorName, String trainerName, int totalDurationInHrs, int totalNumberOfTrainees) {
        this.trainingVendorName = trainingVendorName;
        this.trainerName = trainerName;
        this.totalDurationInHrs = totalDurationInHrs;
        this.totalNumberOfTrainees = totalNumberOfTrainees;
    }
	
	 	@Override
	    public String getTrainigVendorName() {
	 	// TODO Auto-generated method stub
	        return trainingVendorName;
	    }

	    @Override
	    public String getTrainerName() {
	    // TODO Auto-generated method stub
	        return trainerName;
	    }

	    @Override
	    public int getTotalDurtionInHrs() {
	    // TODO Auto-generated method stub
	        return totalDurationInHrs;
	    }

	    @Override
	    public int getTotalNumberOfTrainees() {
	    // TODO Auto-generated method stub
	        return totalNumberOfTrainees;
	    }

}
