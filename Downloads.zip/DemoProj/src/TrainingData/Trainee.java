package TrainingData;

public class Trainee implements Training{
	private String traineeName;
    private String trainerName;
    private String trainingVendorName;
    private int totalDurationInHrs;
    private int totalNumberOfTrainees;

    public Trainee(String traineeName, String trainerName) {
        this.traineeName = traineeName;
        this.trainerName = trainerName;
        autoAssignValues();
    }

    // Private method to auto-assign values based on trainerName
    private void autoAssignValues() {
        if (trainerName.equalsIgnoreCase("Bidesh")) {
            trainingVendorName = "ABC Training";
            totalDurationInHrs = 20;
            totalNumberOfTrainees = 50;
        } else if (trainerName.equalsIgnoreCase("BijayaLaxmi")) {
            trainingVendorName = "XYZ Training";
            totalDurationInHrs = 15;
            totalNumberOfTrainees = 40;
        } else {
            // Default values or logic for unknown trainerName
            trainingVendorName = "Unknown Vendor";
            totalDurationInHrs = 10;
            totalNumberOfTrainees = 20;
        }
    }

    @Override
    public String getTrainigVendorName() {
        return trainingVendorName;
    }

    @Override
    public String getTrainerName() {
        return trainerName;
    }

    @Override
    public int getTotalDurtionInHrs() {
        return totalDurationInHrs;
    }

    @Override
    public int getTotalNumberOfTrainees() {
        return totalNumberOfTrainees;
    }

    // Getter for traineeName
    public String getTraineeName() {
        return traineeName;
    }

}
