//
//public class FourDArr {
//
//    public static void main(String[] args) {
//        // Define dimensions for the 4D array
//        int dim1 = 2;
//        int dim2 = 3;
//        int dim3 = 4;
//        int dim4 = 5;
//
//        // Create a 4D array with the specified dimensions
//        int[][][][] fourDArray = new int[dim1][dim2][dim3][dim4];
//
//        // Initialize the elements of the array (optional)
//        int value = 1;
//        for (int i = 0; i < dim1; i++) {
//            for (int j = 0; j < dim2; j++) {
//                for (int k = 0; k < dim3; k++) {
//                    for (int l = 0; l < dim4; l++) {
//                        fourDArray[i][j][k][l] = value;
//                        value++;
//                    }
//                }
//            }
//        }
//
//        // Print the elements of the 4D array
//        for (int i = 0; i < dim1; i++) {
//            for (int j = 0; j < dim2; j++) {
//                for (int k = 0; k < dim3; k++) {
//                    for (int l = 0; l < dim4; l++) {
//                        System.out.print(fourDArray[i][j][k][l] + " ");
//                    }
//                    System.out.println();
//                }
//                System.out.println();
//            }
//            System.out.println();
//        }
//    }
//}
//
