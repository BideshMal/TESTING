package com.java.day1;

public class calcChars {
	public static int calcChars(String S) {
		int noOfChars=S.length();
		
		return noOfChars;
	}
	public static void main(String[] args) {
		int N=calcChars("Bidesh");
		
		System.out.println(N);		
	}

}
