package com.java.day2;

public interface Employee {
	public static final int comapny_code = 0011;
	
	void empLogin();

}
