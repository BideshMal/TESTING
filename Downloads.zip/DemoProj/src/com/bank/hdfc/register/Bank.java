package com.bank.hdfc.register;

public class Bank {
	String Name;
	String IFSC_code;
	public static void CreditCardApproval(int creditScore) {
		
	}
	
}
